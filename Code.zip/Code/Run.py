import numpy as np
import read
from sklearn.utils import shuffle

import proposed.run



def get_n_parties(Data, target, n_clusters):  # grouping the data
    cluster_label = []
    cluster_data = []
    target = shuffle(target)

    for k in range(n_clusters):
        cluster_data.append([])  # create a array using n_cluster value
        cluster_label.append([])  # create a array using n_cluster value

    n1 = int(len(Data) / n_clusters)
    m = 0
    for i in range(n_clusters):
        for j in range(n1):
            cluster_data[i].append(Data[m])
            cluster_label[i].append(target[m])
            m = m + 1

    return cluster_data, cluster_label



ts = 10  #  time stamp
data, target = read.main()   # read data
n = 3
clustrd_data, clustrd_lab = get_n_parties(data, target, n)

ACC, Loss, MAP, MSE = [], [], [], []
for i in range(5):
    #--------          proposed             ---------------------------------------------

    proposed.run.Multi_Party_system(clustrd_data, clustrd_lab, target, n, ACC, Loss, MAP, MSE, ts)

    ts += 10

print(ACC, Loss, MAP)
