import random
import pandas as pd
import numpy as np




def main():

    d1 = pd.read_csv('dataset\\processed.cleveland.data',header=None)

    data = np.array(d1)
    target = data[:,-1].astype(float)
    data = data[:,:-1]

    for i in range(len(data)):
        for j in range(data.shape[1]):
            try:
                data[i,j] = float(data[i,j])
            except:
                data[i, j] = random.random()
    data = data.astype(float)
    return data, target


