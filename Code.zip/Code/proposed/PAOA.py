import random
from proposed.fitness import fitness
import numpy as np
def get_key_matrix(k,data):

    k_mat = []
    for i in range(len(data)):
        k_mat.append(random.randint(0,1))
    sz = len(k_mat)
    if sz > k :
        sz = sz - k
        k_mat = []
        for i in range(sz):
            k_mat.append(random.randint(0, 1))
    else:
        pass
    return sz,np.array(k_mat)
def acceleration_update(x,den,vol):
    den_mr = random.uniform(0,1)
    vol_mr = random.uniform(0, 1)
    acc_mr = random.uniform(0, 1)
    soln = []
    for i in range(len(x)):
        soln.append((den_mr + vol_mr * acc_mr) / (den[i] * vol[i]))
    return soln

def acceleration_exploit(x,den,vol,den_best,vol_best,acc_best):

    soln = []
    for i in range(len(x)):
        soln.append((den_best + vol_best * acc_best) / (den[i] * vol[i]))
    return soln

def acceleration_norm(x,acc):
    u, l = 0.9, 0.1
    soln = []
    for i in range(len(x)):
        soln.append(u * ((acc[i] - np.min(acc)) / (np.max(acc) - np.min(acc))) + l)
    return soln


def init_P(N,M): # initialize particles
    lb,ub = 0,10
    data = []
    for i in range(N):
        temp = []
        for j in range(M):
            temp.append(random.uniform(lb,ub))
        data.append(temp)
    return data

def fit(solution): # fitness calculation
    fit = []
    for i in range(len(solution)):
        fit.append(random.uniform(0,1))
    return fit

def soln(X,GM,F,Fg,r):
    I = np.round(1 + r)                             # eq 6
    DX = []
    for i in range(len(X)):
        dx = []
        for j in range(len(X[0])):
            if Fg[i]<F[i]:
                dx.append(GM[i][j] - I * X[i][j])
            else:
                dx.append(X[i][j] - I * GM[i][j])
        DX.append(dx)
    return DX

def update_soln(x,best):
    data = []
    for i in range(len(x)):
        data.append(x[i] + random.uniform(-1,1) * (best - x[i]))
    return data
def new_x(X,dX,delt,acc_norm,d):
    r = random.randint(0,1)
    f = random.uniform(0,1)
    C1, C2, C3, C4 = 2, 6, 2, 0.5
    x=[]
    for i in range(2,len(X)):   ######### proposed update
        sol = (C1 *r *acc_norm[i]*d *X[i][r] *(1+r+d))/(X[i][r]*acc_norm[i]*d+r*d)
        x.append(sol)
    return x
def acceleration(N,ub,lb):
    data = []
    for i in range(len(N)):
        data.append(lb + random.uniform(0,1)*(ub-lb))
    return data

def intialize(x):
    soln = []
    for i in range(len(x)):
        soln.append(random.uniform(0,1))
    return soln
def algm(k,data,enc):
    N,M = 10, 10
    t, Max_itr = 1,10

    pop = init_P(N,M)                           # eq1
    F = fit(pop)                            # eq2

    bst = min(F)                                # eq3
    den = intialize(pop)
    vol = intialize(pop)  # eq(5)
    lb, ub = 1, 5
    acc = acceleration(pop, ub, lb)  # eq(6)
    r = random.uniform(-1, 1)
    Fit = fitness(pop, data, enc,k)
    den_best = np.max(Fit)
    vol_best = np.argmax(Fit)
    
    import math
    while t<=Max_itr:
        TF = math.exp((t - Max_itr) / Max_itr)
        d = math.exp((Max_itr - t) / Max_itr) - (t / Max_itr)
        over_allbst =[]
        Xi=[]
        r = random.randint(0,1)
        GM = init_P(N,M)                        # eq4
        Fg = fit(GM)
        dx = soln(pop,GM,F,Fg,r)                # eq5
        den_update = update_soln(den, den_best)
        vol_update = update_soln(vol, vol_best)
        acc_explore = acceleration_update(pop, den_update, vol_update)  # eq(10)
        acc_norm = acceleration_norm(pop, acc_explore)
        X_new = new_x(pop,dx,Fg,acc_norm,d)                   # eq7
        F_new = fit(X_new)
        for i in range(len(pop)-2):               # eq8
            if F_new[i]<F[i]:
                Xi.append(X_new[i])
            else:
                Xi.append(pop[i])

        Np = np.round(0.5 * (1- (t/Max_itr) * N))       # eq9

        X_new = init_P(N,M)
        F_new = fit(X_new)
        for i in range(len(pop)-2):
            if F_new[i]<F[i]:
                Xi[i]=(X_new[i])
            else:
                Xi[i]=(pop[i])
        over_allbst.append(min(F_new))
        t=t+1
    sz, mat = get_key_matrix(k, data)
    return sz, mat





