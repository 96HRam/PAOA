import proposed.HE_updated as rlwe_updated
import numpy as np
import proposed.PAOA
import random
from sklearn.utils import shuffle
import random
from Crypto.Util import number
# from random import shuffle


# Distribution for the public key generation
def distribution(gamma, rho, sk):
    r = random.randint(2 ** (int(rho - 1)), 2 ** rho)
    q = random.randint((2 ** (gamma / 2) / sk), ((2 ** gamma) / sk))
    return q * sk + r


# Distribution for a layer encryption
def Z_distribution(gamma, lmb, N, i):
    param = random.randint(int((N ** i) * gamma * (N - 1) * (lmb ** 0.01) + i),
                           int((N ** i) * gamma * (N - 1) * (lmb ** 0.05) + i))
    Z1 = 0
    while (Z1.bit_length() != param):
        Z1 = random.getrandbits(param)
        if Z1 % 2 == 0: Z1 += 1
    return Z1


# check even or odd
def check(x, sk):
    ans = True
    if (x % 2 == 1):
        ans = True
    else:
        ans = False
    if ((x % sk) % 2 == 0):
        ans *= True
    else:
        ans *= False
    return ans


# Generate private and public keys
def keygen(eta, tau, gamma, rho):
    sk = number.getPrime(eta)
    pk = []
    for i in range(0, tau + 1):
        pk.append(distribution(gamma, rho, sk))
    pk.sort(reverse=True)
    while check(pk[0], sk) != 1:
        for i in range(0, tau + 1):
            pk[i] = distribution(gamma, rho, sk)
        pk.sort(reverse=True)
    return pk


def main(data, target, round, dec,ts):
    # ciphertext modulus
    q = 2 ** 14
    # plaintext modulus
    t = data.shape[0]
    # base for relin_v1
    T = int(np.sqrt(q))
    # modulusswitching modulus
    p = ts ** 3

    # polynomial modulus
    poly_mod = target

    # standard deviation for the error in the encryption
    std1 = 1
    # standard deviation for the error in the evaluateKeyGen_v2
    std2 = 1
    pk = (data)
    lim = len(pk) + 1
    '''    ###########       MULTI_KEY APPROACH              #####################################################'''
    # Keygen
    n, sk = proposed.PAOA.algm(lim, data, dec[round])


    # EvaluateKeygen_version1
    rlk0_v1, rlk1_v1 = rlwe_updated.evaluate_keygen_v1(sk, n, q, T, poly_mod, std1)

    # EvaluateKeygen_version2
    rlk0_v2, rlk1_v2 = rlwe_updated.evaluate_keygen_v2(sk, n, q, poly_mod, p, std2)

    # Encryption
    pt1, pt2 = list(shuffle(target)), list(shuffle(target))

    cst1, cst2 = list(shuffle(target)), list(shuffle(target))

    ct1 = rlwe_updated.encrypt(pk, n, q, t, poly_mod, pt1, std1)
    ct2 = rlwe_updated.encrypt(pk, n, q, t, poly_mod, pt2, std1)

    '''               Evaluation             '''
    ct3 = rlwe_updated.add_plain(ct1, cst1, q, t, poly_mod)
    ct4 = rlwe_updated.mul_plain(ct2, cst2, q, t, poly_mod)
    # ct5 = (ct1 + cst1) + (cst2 * ct2)
    ct5 = rlwe_updated.add_cipher(ct3, ct4, q, poly_mod)
    # ct6 = ct1 * ct2
    ct6 = rlwe_updated.mul_cipher_v1(ct1, ct2, q, t, T, poly_mod, rlk0_v1, rlk1_v1)
    ct7 = rlwe_updated.mul_cipher_v2(ct1, ct2, q, t, p, poly_mod, rlk0_v2, rlk1_v2)



    # # Decryption
    skz=n

    decrypted_ct3 = rlwe_updated.decrypt(sk, skz, q, t, poly_mod, ct3)
    decrypted_ct4 = rlwe_updated.decrypt(sk, skz, q, t, poly_mod, ct4)
    dec.append(decrypted_ct3)



