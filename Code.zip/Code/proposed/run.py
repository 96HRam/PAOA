from proposed import Homomorphic_encryption_MultiKey
import random
from proposed import DRN
import numpy as np
import threading
def generate(n):
    n= np.array(n)
    en = n.copy()
    for i in range(len(n)):
        for j in range(n.shape[1]):
            en[i, j] = random.random()
    return en

def local_model(data,target,tr,ACC,Loss,P, MSE):
    weight =[]
    #----  Local training via Deep residual learning, training based on PAOA
    DRN.classify(np.array(data), np.array(target), tr,ACC,Loss,P,MSE, weight)
    return weight


class GlobalModel(object):
    def __init__(self):
        self.weights = 0
        self.num_samples = 0
        self.lock = threading.Lock()

    def aggregate_weights(self, num_samples, weights, ts):
        with self.lock:
            self.num_samples += num_samples*ts
            # for sw, w in zip(self.weights, weights):
            #     sw += num_samples * w*ts
        AVG_W = sum(weights)/num_samples  #### averaging weights
        return AVG_W

    def get_weights(self):
        with self.lock:
            if self.num_samples == 0:
                return self.weights

            for w in self.weights:
                w /= self.num_samples
            self.num_samples = 0
            return self.weights

def Multi_Party_system(clus_data,target,lab,n,ACC,Loss,MAP,MSE,ts):
    acc, loss,pre, mse= [], [], [], []
    data = []
    for i in range(n):
        dec = []
        dec.append(generate(clus_data[i]))

        rounds = len(clus_data[i])

        for j in range(rounds):
            #-----  Noise free Multi-Key Homomorphic encryption
            Homomorphic_encryption_MultiKey.main(np.array(clus_data[i]), np.array(target[i]), j, dec,ts)
        dec = dec[1:]

        data.append(dec)
        ##############   local_model
        weight = local_model(dec, target[i], 0.99, acc, loss, pre, mse)

        ### global_model
        GL = GlobalModel()  #### global model
        GL.aggregate_weights(n, weight, ts)  #### weight aggregation update to server
    ACC.append(np.average(acc))
    Loss.append(np.average(loss))
    MAP.append(np.average(pre))
    MSE.append(np.average(mse))

