import numpy as np


def Accuracy(ori, enc):
    enc = np.resize(enc,(ori.shape))
    acc = np.sum(np.equal(ori,enc)) / len(enc)
    return acc

def privacy(ori,enc):
    enc = np.resize(enc, (ori.shape))
    dot_product = ori *enc
    norm_vector1 = np.linalg.norm(ori)
    norm_vector2 = np.linalg.norm(enc)
    cosine_similarity = (dot_product / (norm_vector1 * norm_vector2)).mean()
    return cosine_similarity


def fitness(soln, ori_data, enc_data,k):
    Fit = []
    if np.linalg.det(soln) !=0:
        invertible = True
    else:
        invertible = False
    for i in range(len(soln)):

        ac = Accuracy(ori_data,enc_data)

        P = privacy(ori_data,enc_data)

        if invertible == True:

            fit = 1/2 *(ac+(1-P)+(1-k))
        else:
            fit=0
        Fit.append(fit)

    return Fit
